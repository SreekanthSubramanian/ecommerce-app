# ecommerce_riverpod

A new Flutter project.

## Getting Started

This is a simple E-commerce App with Riverpod. <br>

<table>
  <tr>
  <td> 
<img src = "https://github.com/Bucerella/Ecommerce/blob/master/assets/s1.png" width = 400>
  </td>
     <td> 
<img src = "https://github.com/Bucerella/Ecommerce/blob/master/assets/s2.png" width = 400>
  </td>
     <td> 
<img src = "https://github.com/Bucerella/Ecommerce/blob/master/assets/s3.png" width = 400>
  </td>
  </tr>

 
</table>

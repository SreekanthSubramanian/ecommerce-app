package com.example.ecommerce_riverpod

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
